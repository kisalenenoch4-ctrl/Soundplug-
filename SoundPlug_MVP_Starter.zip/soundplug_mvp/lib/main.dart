import 'package:flutter/material.dart';

void main() => runApp(const SoundPlugApp());

class Beat {
  final String title, producer, genre, mood, bpm, price;
  const Beat(this.title, this.producer, this.genre, this.mood, this.bpm, this.price);
}

const beats = [
  Beat('Forever', 'jp', 'Trap', 'Dark', '124 BPM', '₦10,000'),
  Beat('Lagos Nights', 'TeeBeats', 'Afrobeats', 'Chill', '98 BPM', '₦8,000'),
  Beat('No Sleep', 'KxngVibes', 'Trap', 'Motivational', '140 BPM', '₦7,500'),
  Beat('City Lights', 'ProdByZee', 'Afrobeats', 'Happy', '105 BPM', '₦7,000'),
];

class SoundPlugApp extends StatelessWidget {
  const SoundPlugApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SoundPlug',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF070B09),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF39FF14),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  final pages = const [
    HomePage(),
    DiscoverPage(),
    LibraryPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.library_music_outlined), label: 'Library'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Row(
          children: [
            const Expanded(child: Text('SoundPlug', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800))),
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
          ],
        ),
        const Text('Find your sound. Build your wave.', style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 18),
        TextField(
          decoration: InputDecoration(
            hintText: 'Search beats, producers, genres...',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: Colors.white10,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [Color(0xFF12351A), Color(0xFF0B1710)]),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Your next hit is here.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              Text('Discover beats from producers across Africa.', style: TextStyle(color: Colors.white70)),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const SectionTitle('Trending Beats'),
        const SizedBox(height: 10),
        ...beats.map((b) => BeatTile(beat: b)),
      ],
    );
  }
}

class DiscoverPage extends StatefulWidget {
  const DiscoverPage({super.key});
  @override
  State<DiscoverPage> createState() => _DiscoverPageState();
}

class _DiscoverPageState extends State<DiscoverPage> {
  String genre = 'All';
  @override
  Widget build(BuildContext context) {
    final filtered = genre == 'All' ? beats : beats.where((b) => b.genre == genre).toList();
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('Discover', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        TextField(
          decoration: InputDecoration(
            hintText: 'Search...',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: Colors.white10,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          children: ['All', 'Afrobeats', 'Trap', 'Drill', 'R&B'].map((g) {
            return ChoiceChip(
              label: Text(g),
              selected: genre == g,
              onSelected: (_) => setState(() => genre = g),
            );
          }).toList(),
        ),
        const SizedBox(height: 20),
        ...filtered.map((b) => BeatTile(beat: b)),
      ],
    );
  }
}

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('My Library', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Your purchased beats will appear here.', style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 20),
        const BeatTile(beat: beats[0], purchased: true),
      ],
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const CircleAvatar(radius: 44, child: Icon(Icons.person, size: 45)),
        const SizedBox(height: 12),
        const Center(child: Text('Snappy', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
        const Center(child: Text('Artist', style: TextStyle(color: Colors.white60))),
        const SizedBox(height: 28),
        ListTile(leading: const Icon(Icons.favorite_border), title: const Text('Favorites'), onTap: () {}),
        ListTile(leading: const Icon(Icons.download_outlined), title: const Text('Downloads'), onTap: () {}),
        ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('Settings'), onTap: () {}),
      ],
    );
  }
}

class BeatTile extends StatelessWidget {
  final Beat beat;
  final bool purchased;
  const BeatTile({super.key, required this.beat, this.purchased = false});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white.withOpacity(.06),
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        contentPadding: const EdgeInsets.all(8),
        leading: Container(
          width: 58, height: 58,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: const LinearGradient(colors: [Color(0xFF39FF14), Color(0xFF164D1A)]),
          ),
          child: const Icon(Icons.music_note, color: Colors.black),
        ),
        title: Text(beat.title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${beat.producer} • ${beat.genre} • ${beat.bpm}'),
        trailing: purchased
            ? IconButton(icon: const Icon(Icons.download_outlined), onPressed: () {})
            : Text(beat.price, style: const TextStyle(color: Color(0xFF39FF14), fontWeight: FontWeight.bold)),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BeatPage(beat: beat))),
      ),
    );
  }
}

class BeatPage extends StatefulWidget {
  final Beat beat;
  const BeatPage({super.key, required this.beat});
  @override
  State<BeatPage> createState() => _BeatPageState();
}

class _BeatPageState extends State<BeatPage> {
  bool playing = false;
  String license = 'MP3 Basic';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Beat')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            height: 280,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF39FF14), Color(0xFF0B1710)]),
            ),
            child: const Icon(Icons.graphic_eq, size: 100, color: Colors.black),
          ),
          const SizedBox(height: 20),
          Text(widget.beat.title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          Text('by ${widget.beat.producer}', style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 12),
          Text('${widget.beat.genre} • ${widget.beat.mood} • ${widget.beat.bpm}'),
          const SizedBox(height: 22),
          FilledButton.icon(
            onPressed: () => setState(() => playing = !playing),
            icon: Icon(playing ? Icons.pause : Icons.play_arrow),
            label: Text(playing ? 'Pause Preview' : 'Play Preview'),
          ),
          const SizedBox(height: 24),
          const Text('License', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          RadioListTile<String>(value: 'MP3 Basic', groupValue: license, onChanged: (v) => setState(() => license = v!), title: const Text('MP3 Basic'), subtitle: Text(widget.beat.price)),
          RadioListTile<String>(value: 'WAV Premium', groupValue: license, onChanged: (v) => setState(() => license = v!), title: const Text('WAV Premium'), subtitle: const Text('₦15,000')),
          RadioListTile<String>(value: 'Exclusive', groupValue: license, onChanged: (v) => setState(() => license = v!), title: const Text('Exclusive'), subtitle: const Text('₦30,000')),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: () => showDialog(
              context: context,
              builder: (_) => AlertDialog(
                title: const Text('Demo checkout'),
                content: Text('You selected $license for ${widget.beat.title}. Real payment processing will be connected in the next phase.'),
                actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
              ),
            ),
            child: const Text('Buy Now'),
          ),
        ],
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold));
}

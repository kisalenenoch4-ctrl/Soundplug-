# SoundPlug MVP

A starter Flutter app for a beat marketplace connecting artists and producers.

## Included
- Dark SoundPlug visual identity
- Home / Discover / Library / Profile navigation
- Search bar and genre chips
- Beat cards with preview buttons
- Beat detail screen with license options
- Demo purchase flow (no real payments yet)
- Sample producer profile and library

## Run
1. Install Flutter.
2. Create a new Flutter project with `flutter create soundplug`.
3. Replace its `lib/main.dart` with this project's `lib/main.dart`.
4. Run `flutter pub get` and `flutter run`.

This MVP intentionally uses demo data. Real authentication, audio hosting, licensing, payment processing, producer payouts, and secure downloads should be added before accepting real money.
